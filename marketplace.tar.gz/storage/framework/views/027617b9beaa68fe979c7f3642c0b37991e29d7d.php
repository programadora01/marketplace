<?php $__env->startSection('content'); ?>


<h2 class="alert alert-success">
    Muito obrigado(a) por sua compra!
</h2>
<h3>
    Seu pedido foi processado com sucesso, código do pedido: <?php echo e(request()->get('order')); ?>

</h3>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\marcos\blog\resources\views/thanks.blade.php ENDPATH**/ ?>
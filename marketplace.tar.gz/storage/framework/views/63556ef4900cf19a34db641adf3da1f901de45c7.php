<?php $__env->startSection('content'); ?>

<?php if(!$onwers): ?>
<a href="/#" class="btn btn-lg btn-success">Gestão de Lojistas</a>
<?php else: ?>
<table class="table table-striped">
    <thead>
        <tr>
            <th>#</th>
            <th>Nome</th>
            <th>E-mail</th>
            <th>Loja</th>
            <th>Permissão</th>
            <th>Ação</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $onwers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onwer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($onwer->id); ?></td>
            <td><?php echo e($onwer->name); ?></td>
            <td><?php echo e($onwer->email); ?></td>
            <td><?php echo e($onwer->store->name); ?></td>
            <td><?php echo e($onwer->role); ?></td>
            <td>
                <div class="btn-group">
                    <a href="/#" class="btn btn-sm btn-primary">Editar</a>&nbsp;&nbsp;
                    <form action="/#" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <button type="submit" class="btn btn-sm btn-danger">Remover</button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php endif; ?>

<?php echo e($onwers->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\marcos\blog\resources\views/admin/onwers/index.blade.php ENDPATH**/ ?>
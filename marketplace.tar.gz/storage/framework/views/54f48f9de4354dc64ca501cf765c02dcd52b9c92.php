<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Marketplace L6</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>
        .front.row {
            margin-bottom: 40px;
        }
    </style>
    <?php echo $__env->yieldContent('stylesheets'); ?>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light" style="margin-bottom: 40px;">

        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Marketplace L6</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">

            <ul class="navbar-nav mr-auto">
                <li class="nav-item <?php if(request()->is('/')): ?> active <?php endif; ?>">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Home <span class="sr-only">(current)</span></a>
                </li>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item  <?php if(request()->is('category/' . $category->slug)): ?> active <?php endif; ?>">
                    <a class="nav-link" href="<?php echo e(route('category.single', ['slug' => $category->slug])); ?>"><?php echo e($category->name); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <div class="my-2 my-lg-0">
                <ul class="navbar-nav mr-auto">
                    <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item <?php if(request()->is('my-orders')): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(route('user.orders')); ?>">Meus Pedidos</a>
                    </li>
                    <?php endif; ?>

                    <li class="nav-item <?php if(request()->is('my-orders')): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">Entrar</a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('cart.index')); ?>" class="nav-link">
                            <?php if(session()->has('cart')): ?>
                            <!--<span class="badge badge-danger"><?php echo e(count(session()->get('cart'))); ?></span>-->
                            <span class="badge badge-danger"><?php echo e(array_sum(array_column(session()->get('cart'), 'amount'))); ?></span>
                            <?php endif; ?>
                            <i class="fa fa-shopping-cart fa-1x"></i>
                        </a>

                    </li>

                    <li class="nav-item">
                        <form action="<?php echo e(route('logout')); ?>" class="logout" method="POST" style="display:none;">
                            <?php echo csrf_field(); ?>
                        </form>
                        <a class="nav-link" href="#" onclick="event.preventDefault();
                                                                  document.querySelector('form.logout').submit(); ">Sair</a>


                    </li>
                </ul>
            </div>


        </div>
    </nav>

    <div class="container">
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\Xampp\htdocs\marcos\blog\resources\views/layouts/front.blade.php ENDPATH**/ ?>
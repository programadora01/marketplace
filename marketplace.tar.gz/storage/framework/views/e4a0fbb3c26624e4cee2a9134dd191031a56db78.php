<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <a href="<?php echo e(route('admin.notifications.read.all')); ?>" class="btn btn-lg btn-success">Marcar todas como lidas!</a>
    </div>
</div>

<br>

<table class="table table-striped">
    <thead>
        <tr>
            <th>Notificação</th>
            <th>Criado em</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($n->data['message']); ?></td>
            <td><?php echo e($n->created_at->locale('pt')->diffForHumans()); ?></td>
            <td>
                <div class="btn-group">
                    <a href="<?php echo e(route('admin.notifications.read', ['notification' => $n->id])); ?>" class="btn btn-sm btn-primary">Marcar como lida</a>
                </div>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <td colspan="3">
            <div class="alert alert-warning">Nenhuma notificação encontrada!</div>
        </td>
        <?php endif; ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\marcos\blog\resources\views/admin/notifications.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<?php if(!$store): ?>

<a href="<?php echo e(route('admin.stores.create')); ?>" class="btn btn-lg btn-success">Criar Loja</a>

<?php else: ?>

<table class="table table-striped">
    <thead>
        <tr>
            <th>#</th>
            <th>Loja</th>
            <th>Total de Produtos</th>
            <th>Ação</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><?php echo e($store->id); ?></td>
            <td><?php echo e($store->name); ?></td>
            <td><?php echo e($store->products->count()); ?></td>
            <td>
                <div class="btn-group">
                    <a href="<?php echo e(route('admin.stores.edit', ['store' => $store->id])); ?>" class="btn btn-sm btn-primary">Editar</a>&nbsp;&nbsp;
                    <form action="<?php echo e(route('admin.stores.destroy', ['store' => $store->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <button type="submit" class="btn btn-sm btn-danger">Remover</button>
                    </form>
                </div>
            </td>
        </tr>
    </tbody>
</table>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\marcos\blog\resources\views/admin/stores/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-12">

            <h2>Carrinho de Compras</h2>

            <hr>
      
        </div>

        <div class="col-12">

            <?php if($cart): ?>

                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Produto</th>
                            <th>Preço</th>
                            <th>Quantidade</th>
                            <th>Subtotal</th>
                            <th>Ação</th>
                        </tr>

                    </thead>
                    <tbody>

                        <?php $total = 0; ?>

                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($c['name']); ?></td>
                                <td>R$ <?php echo e(number_format($c['price'], 2, ',', '.')); ?></td>
                                <td><?php echo e($c['amount']); ?></td>

                                <?php
                                    $subtotal = $c['price'] * $c['amount'];
                                    $total += $subtotal;
                                ?>

                                <td>R$ <?php echo e(number_format(($c['price'] * $c['amount']), 2, ',', '.')); ?></td>
                                <td>
                                <a href="<?php echo e(route('cart.remove', ['slug' => $c['slug']])); ?>" class="btn btn-sm btn-danger">Remover</a>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td colspan="3">Total:</td>
                            <td colspan="2">R$ <?php echo e(number_format($total, 2, ',', '.')); ?></td>
                        </tr>

                    </tbody>

                </table>
                <hr>

                <div class="col-md12">
                <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-lg btn-success float-right">Finalizar Compra</a>
                <a href="<?php echo e(route('cart.cancel')); ?>" class="btn btn-lg btn-danger float-left">Cancelar Compra</a>
                </div>

            <?php else: ?>

                <div class="alert alert-warning">Carrinho vazio...</div>

            <?php endif; ?>    
        
        
        </div>
    
    </div>















<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\marcos\blog\resources\views/cart.blade.php ENDPATH**/ ?>
<h1>Olá, <?php echo e($user->name); ?>, tudo bem? Espero que sim!</h1>

<h3>Obrigado por sua inscrição!</h3>
<p>
    Faça bom proveito e xexcelentes compras em nosso0 marketplace! <br>
    Seu email de cadastro é: <strong><?php echo e($user->email); ?></strong> <br>
    Sua senha: <strong>Porsegurança não enviamos sua senha, mas acreditamos que você deve lembrar!</strong>
</p>

<hr>

Email enviado em <?php echo e(date('d/m/y H:i:s')); ?>.
<?php /**PATH C:\Xampp\htdocs\marcos\blog\resources\views/emails/user-registered.blade.php ENDPATH**/ ?>
<?php $__env->startSection('stylesheets'); ?>

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="container">

    <div class="col-md-6">
        <div class="row">
            <div class="col-md-12 msg">

            </div>
        </div>

        <div class="row">

            <div class="col-md-12">
                <h2>Dados de Pagamento</h2>
                <hr>
            </div>

        </div>

        <form action="" method="post">

            <div class="row">

                <div class=" col-md-12 form-group">
                    <label>Nome no Cartão</label>
                    <input type="text" class="form-control" name="card_name">
                </div>

            </div>



            <div class="row">

                <div class=" col-md-12 form-group">
                    <label>Número do Cartão <span class="brand"></span></label>
                    <input type="text" class="form-control" name="card_number">
                    <input type="hidden" name="card_brand">
                </div>

            </div>

            <div class="row">

                <div class="col-md-4 form-group">
                    <label>Mês vencimento</label>
                    <input type="text" class="form-control" name="card_month">
                </div>

                <div class="col-md-4 form-group">
                    <label>Ano vencimento</label>
                    <input type="text" class="form-control" name="card_year">
                </div>

            </div>

            <div class="row">

                <div class="col-md-5 form-group">
                    <label>Código de Segurança</label>
                    <input type="text" class="form-control" name="card_cvv">
                </div>

                <div class="col-md-12 installments form-group">

                </div>

            </div>

            <button class="btn btn-success btn-lg processCheckout">Efetuar Pagamento</button>

        </form>

    </div>


</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="https://stc.sandbox.pagseguro.uol.com.br/pagseguro/api/v2/checkout/pagseguro.directpayment.js"></script>
<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
    const sessionId = '<?php echo e(session()->get("pagseguro_session_code")); ?>';
    const urlThanks = '<?php echo e(route("checkout.thanks")); ?>';
    const urlProccess = '<?php echo e(route("checkout.proccess")); ?>';
    const amountTransaction = '<?php echo e($cartItems); ?>';
    const csrf = '<?php echo e(csrf_token()); ?>';

    console.log(sessionId);

    PagSeguroDirectPayment.setSessionId(sessionId);
</script>

<script src="<?php echo e(asset('js/pagseguro_functions.js')); ?>"></script>
<script src="<?php echo e(asset('js/pagseguro_events.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\marcos\blog\resources\views/Checkout.blade.php ENDPATH**/ ?>
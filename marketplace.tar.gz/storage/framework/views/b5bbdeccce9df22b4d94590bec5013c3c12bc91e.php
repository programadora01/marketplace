<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <h2>Pedidos Recebidos</h2>
        </h2>
        <hr>

        <div id="accordion">
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card">
                <div class="card-header" id="headingOne">
                    <h5 class="mb-0">
                        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne<?php echo e($key); ?>" aria-expanded="true" aria-controls="collapseOne">
                            Pedido nº: <?php echo e($order->reference); ?>

                        </button>
                    </h5>
                </div>

                <div id="collapseOne<?php echo e($key); ?>" class="collapse <?php if($key == 0): ?> show <?php endif; ?>" aria-labelledby="headingOne" data-parent="#accordion">
                    <div class="card-body">
                        <h1>ID Loja usuário: <?php echo e(auth()->user()->store->id); ?></h1>

                        <ul>
                            <?php $items = unserialize($order->items); ?>

                            <?php $__currentLoopData = filtersItemsByStoreId($items, auth()->user()->store->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li><?php echo e($item['name']); ?> | R$ <?php echo e(number_format($item['price'] * $item['amount'], 2, ',', '.')); ?></li>
                            <br>
                            Quanttidade pedida: <?php echo e($item['amount']); ?>

                            <br>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="alert alert-warning">Nenhum pedido receido</div>
            <?php endif; ?>

        </div>

        <div class="col-12">
            <hr>
            <?php echo e($orders->links()); ?>

        </div>



    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\marcos\blog\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>
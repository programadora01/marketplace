<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-6">

        <?php if($product->photos->count()): ?>

        <img src="<?php echo e(asset('storage/' . $product->thumb)); ?>" alt="" class="card-img-top thumb">

        <div class="row" style="margin-top: 20px;">

            <?php $__currentLoopData = $product->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-4">
                <img src="<?php echo e(asset('storage/' . $photo->image)); ?>" alt="" class="img-fluid img-small">
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <?php else: ?>
        <img src="<?php echo e(asset('assets/img/no-photo.jpg')); ?>" alt="" class="card-img-top">
        <?php endif; ?>

    </div>

    <div class="col-6">


        <div class="col-md-12">

            <h2>
                <?php echo e($product->name); ?>

            </h2>

            <p>
                <?php echo e($product->description); ?>

            </p>

            <h3>
                <?php echo e(number_format($product->price, '2', ',', '.')); ?>

            </h3>

            <span>
                Loja: <?php echo e($product->store->name); ?>

            </span>

        </div>

        <div class="product-add col-md-12">
            <hr>

            <form action="<?php echo e(route('cart.add')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="product[name]" value="<?php echo e($product->name); ?>">
                <input type="hidden" name="product[price]" value="<?php echo e($product->price); ?>">
                <input type="hidden" name="product[slug]" value="<?php echo e($product->slug); ?>">
                <div class="form-group">
                    <label for="">Quantidade</label>
                    <input type="number" name="product[amount]" class="form-control col-md-2" value="1">
                </div>
                <button class="btn btn-lg btn-danger">Comprar</button>
            </form>
        </div>


    </div>

    <div class="row">

        <div class="col-12">
            <hr>
            <?php echo e($product->body); ?>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    let thumb = document.querySelector(`img.thumb`);
    let imgSmall = document.querySelectorAll(`img.img-small`);

    imgSmall.forEach(function(el) {
        el.addEventListener(`click`, function() {
            thumb.src = el.src;

        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\marcos\blog\resources\views/single.blade.php ENDPATH**/ ?>